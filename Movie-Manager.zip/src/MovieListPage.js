import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useGetMoviesQuery } from './moviesApi';
import Header from './Header';
import "./App.scss";
import { Button, Modal } from 'semantic-ui-react';
import { NotificationManager } from 'react-notifications';
import 'semantic-ui-css/semantic.min.css';
import 'react-notifications/lib/notifications.css';




function MovieListPage() {

    const [searchTerm, setSearchTerm] = useState(''); // Initialize searchTerm as empty string
    const { data: movies, isLoading, isError } = useGetMoviesQuery(searchTerm);
    const [cartItems, setCartItems] = useState([]);
    const [isModalOpen, setIsModalOpen] = React.useState(false);


    const handleAddToCart = (movie) => {
        const isMovieInCart = cartItems.some((item) => item.imdbID === movie.imdbID);

        if (isMovieInCart) {
            NotificationManager.error('This movie is already in your cart!');
        } else {
            NotificationManager.success('Added to cart successfully!', 'Success');
            setCartItems((prevItems) => [
                ...prevItems,
                { ...movie, cartItemId: generateCartItemId() },

            ]);

        }

        setIsModalOpen(true);
    };

    const handleRemoveFromCart = (itemId) => {
        NotificationManager.error('This movie is removed fron your cart!');

        setCartItems((prevItems) =>
            prevItems.filter((item) => item.cartItemId !== itemId)
        );
    };

    const generateCartItemId = () => {
        return `${Date.now()}-${Math.random()}`;
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
    };

    const cartItemCount = cartItems.length;
    useEffect(() => {
        setSearchTerm(generateRandomSearchTerm()); // Set the default search term to a random value
    }, []);

    const generateRandomSearchTerm = () => {
        const searchTerms = ['spy', 'action', 'comedy', 'drama']; // Array of predefined search terms
        const randomIndex = Math.floor(Math.random() * searchTerms.length);
        return searchTerms[randomIndex];
    };

    const handleSearch = (e) => {
        e.preventDefault();
        setSearchTerm(e.target.search.value);
    };

    if (isLoading) {
        return <div>Loading movies...</div>;
    }

    if (isError) {
        return <div>Error occurred while fetching movies.</div>;
    }

    return (
        <div>
            <Header cartItemCount={cartItemCount} />
            <form onSubmit={handleSearch} className="search">
                <input type="text" name="search" className="input" placeholder="Search movies..." />
                <button type="submit" className="btn btn-primary search-button">Search</button>
            </form>
            {movies && movies.Search && movies.Search.length > 0 ? (
                <div className="movie-list">
                    {movies.Search.map((movie) => (
                        <div key={movie.imdbID} className="movie-card">
                            <img src={movie.Poster} alt={movie.Title} />
                            <h3>{movie.Title}</h3>
                            <p>Year: {movie.Year}</p>
                            <Button
                                type="button"
                                onClick={() => handleAddToCart(movie)}
                            >
                                Add to Cart
                            </Button>
                            <Link to={`/movies/${movie.imdbID}`}>View Details</Link>
                        </div>
                    ))}
                </div>
            ) : (
                <div>No movies found.</div>
            )}
            <Modal
                open={isModalOpen}
                onClose={handleCloseModal}
                closeIcon
                size="small"
            >
                <Modal.Header>Cart Items</Modal.Header>
                <Modal.Content>
                    {cartItems.length > 0 ? (
                        <ul>
                            {cartItems.map((item) => (
                                <li key={item.cartItemId} className='p-2'>
                                    {item.Title}

                                    <i className="fa fa-trash remove" aria-hidden="true" onClick={() => handleRemoveFromCart(item.cartItemId)}></i>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p>No items in the cart.</p>
                    )}
                </Modal.Content>
                <Modal.Actions>
                    <Button onClick={handleCloseModal}>Close</Button>
                </Modal.Actions>
            </Modal>

        </div>

    );
}

export default MovieListPage;
