import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import MovieListPage from './MovieListPage';
import MovieDetailsPage from './MovieDetailsPage';
import { NotificationContainer } from 'react-notifications';
import 'react-notifications/lib/notifications.css';
import "./App.scss"

const App = () => {
  return (
    <>
      <Router>
        <Switch>
          <Route exact path="/" >
            <MovieListPage
            />
          </Route>
          <Route path="/movies/:imdbID">
            <MovieDetailsPage
            />
          </Route>

        </Switch>
        <NotificationContainer />
      </Router>
    </>

  );
}

export default App;
