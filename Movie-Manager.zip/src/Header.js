import React from 'react';
import { useLocation } from 'react-router-dom';
import "./App.scss"

const Header = ({ cartItemCount }) => {
    const location = useLocation();
    const hideCartIcon = location.pathname.includes('/movies');

    return (
        <header>
            <div className="header">Movie App
                <div className="user-image">
                    {!hideCartIcon && (
                        <div className="cart-icon">
                            <i className="fa fa-cart-arrow-down" aria-hidden="true"></i>
                            {cartItemCount > 0 && <span className="cart-count">{cartItemCount}</span>}
                        </div>
                    )}
                </div>
            </div>

        </header>
    );
}


export default Header;

